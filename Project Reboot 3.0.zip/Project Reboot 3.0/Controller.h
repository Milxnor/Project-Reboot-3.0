#pragma once

#include "Actor.h"

class AController : public AActor
{
public:
};