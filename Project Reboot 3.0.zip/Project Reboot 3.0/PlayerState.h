#pragma once

#include "Actor.h"

class APlayerState : public AActor
{
public:
};