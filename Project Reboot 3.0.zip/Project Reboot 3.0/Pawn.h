#pragma once

#include "Actor.h"

class APawn : public AActor
{
public:
};