#pragma once

#include "GameMode.h"

class AFortGameMode : public AGameMode
{
public:
};