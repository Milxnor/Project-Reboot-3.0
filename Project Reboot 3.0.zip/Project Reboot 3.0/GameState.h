#pragma once

#include "Actor.h"

class AGameState : public AActor
{
public:
};