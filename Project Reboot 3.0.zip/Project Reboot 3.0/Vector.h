#pragma once

struct FVector
{
public:
	float X;
	float Y;
	float Z;
};