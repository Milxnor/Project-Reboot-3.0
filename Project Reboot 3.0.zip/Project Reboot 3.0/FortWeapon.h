#pragma once

#include "Actor.h"

class AFortWeapon : public AActor
{

};