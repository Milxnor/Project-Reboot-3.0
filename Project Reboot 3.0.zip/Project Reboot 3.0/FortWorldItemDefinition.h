#pragma once

#include "FortItemDefinition.h"

class UFortWorldItemDefinition : public UFortItemDefinition
{

};